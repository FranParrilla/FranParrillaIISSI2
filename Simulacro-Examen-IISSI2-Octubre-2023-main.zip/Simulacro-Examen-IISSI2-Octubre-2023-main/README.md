Examen de octubre 2023
