import { initializeServer } from './app.js'

const enableConsoleLog = true
initializeServer(enableConsoleLog)
